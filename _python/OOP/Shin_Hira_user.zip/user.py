class user:
  def __init__(self, name, email):
    self.name = name
    self.email = email
    self.account_balance = 0

  def make_deposit(self, amount):
    self.account_balance += amount
  
  def make_withdrawal(self, amount):
    self.account_balance -= amount

  def display_user_balance(self):
    print("User: "+self.name+", Balance: $"+str(self.account_balance)) 

  def transfer_money(self, user, balance):
    self.make_withdrawal(balance)
    user.make_deposit(balance)



hira = user("Hira Shin", "yadaAthotmail")
aera = user("Aera Shin", "yamaAthotmail")
josh = user("Josh Shin", "yabaAthotmail")

hira.make_deposit(100)
hira.make_deposit(50)
hira.make_deposit(50)
hira.display_user_balance()

aera.make_deposit(500)
aera.make_deposit(500)
aera.make_withdrawal(300)
aera.make_withdrawal(300)
aera.display_user_balance()

josh.make_deposit(200)
josh.make_withdrawal(100)
josh.make_withdrawal(100)
josh.make_withdrawal(100)
josh.display_user_balance()

hira.transfer_money(aera, 100)
hira.display_user_balance()
aera.display_user_balance()