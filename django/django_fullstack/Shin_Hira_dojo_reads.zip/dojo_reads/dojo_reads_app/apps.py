from django.apps import AppConfig


class DojoReadsAppConfig(AppConfig):
    name = 'dojo_reads_app'
