from django.shortcuts import render, redirect
from .models import User, Trip
from django.contrib import messages
import bcrypt
from datetime import datetime

  # {% if messages %}
  # <ul>
  #     {% for message in messages %}
  #     <li style="color: red;">{{ message }}</li>
  #     {% endfor %}
  # </ul>
  # {% endif %}



def root(request):
  context = {
    "users": User.objects.all()
  }
  return render(request, 'login.html', context)

def reg_process(request):
  errors = User.objects.reg_validator(request.POST)
  if len(errors) > 0:
    for val in errors.values():
      messages.error(request, val)
    return redirect('/')
        
  else:
    password = request.POST["password"]
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

    newuser = User.objects.create(
      fname = request.POST["fname"],
      lname = request.POST["lname"],
      email = request.POST["email"],
      password = hashed,
    )
    request.session['user_id'] = newuser.id
    return redirect ('/main')

def login(request):
  errors = User.objects.login_validator(request.POST)
  if len(errors) > 0:
    for val in errors.values():
      messages.error(request, val)
    return redirect('/')

  user = User.objects.filter(email=request.POST['email']) 
  if user: 
    logged_user = user[0] 
    if bcrypt.checkpw(request.POST["password"].encode(), logged_user.password.encode()):
      request.session['user_id'] = logged_user.id
      return redirect('/main')
  else:
      messages.error(request, "Login failed. Try again.")
  return redirect('/')
    
def logout(request):
  request.session.flush()
  return redirect('/')

def delete(request, id):
  d = User.objects.get(id = id)
  d.delete()
  return redirect('/')

# ************************************************************

def main(request):
  print(Trip.objects.exclude(created_by = request.session['user_id']))
  context = {
    "this_user": User.objects.get(id=request.session['user_id']),
    "this_user_trips": User.objects.get(id=request.session["user_id"]).trips.all(),
    "other_trips": Trip.objects.exclude(created_by = request.session['user_id'])
  }
  return render(request, 'main.html', context)

def remove(request, id):
  remove_trip = Trip.objects.get(id=id)
  remove_trip.delete()
  return redirect('/main')

def join(request, id):
  this_user = User.objects.get(id=request.session["user_id"])
  trip_to_join = Trip.objects.get(id=id)

  this_user.trips.add(trip_to_join)
  return redirect("/main")

def cancel(request, id):
  this_user = User.objects.get(id=request.session["user_id"])
  trip_to_join = Trip.objects.get(id=id)

  this_user.trips.remove(trip_to_join)
  return redirect("/main")

# ***********************************************************

def create_trip(request):
  context = {
    "this_user": User.objects.get(id=request.session["user_id"]),
    "all_trips": Trip.objects.all(),
  }
  return render(request, 'create_trip.html', context)

def create_trip_form(request):
  errors = Trip.objects.trip_validator(request.POST)
  if len(errors) > 0:
    for val in errors.values():
      messages.error(request, val)
    return redirect('/trips/new')

  destination = request.POST["destination"]
  start = request.POST["start_date"]
  end = request.POST["end_date"]
  plan = request.POST["plan"]
  this_user = User.objects.get(id=request.session["user_id"])

  new_trip = Trip.objects.create(
    destination = destination,
    start_date = start,
    end_date = end,
    plan = plan,
    created_by = this_user.id,
  )

  this_user.trips.add(new_trip)
  
  return redirect('/main')

# **********************************************************
def edit_trip(request, id):
  start = Trip.objects.get(id=id).start_date.strftime("%Y-%m-%d")
  end = Trip.objects.get(id=id).end_date.strftime("%Y-%m-%d")
  
  context = {
    "this_user": User.objects.get(id=request.session["user_id"]),
    "this_trip": Trip.objects.get(id=id), 
    "start": start,
    "end": end
  }
  return render(request, 'edit.html', context)

def edit_trip_form(request, id):
  errors = Trip.objects.trip_validator(request.POST)
  if len(errors) > 0:
    for val in errors.values():
      messages.error(request, val)
    return redirect(f'/edit/{id}')

  this_trip = Trip.objects.get(id=id)
  this_trip.destination = request.POST["destination"]
  this_trip.start_date = request.POST["start_date"]
  this_trip.end_date = request.POST["end_date"]
  this_trip.plan = request.POST["plan"]
  this_trip.save()
  return redirect('/main')

# ***********************************************
def trip_info_page(request, id):
  this_trip = Trip.objects.get(id=id)
  start = this_trip.start_date.strftime("%m/%d/%Y")
  end = this_trip.start_date.strftime("%m/%d/%Y")
  created = datetime.date(this_trip.created_at).strftime("%m/%d/%Y")
  updated = datetime.date(this_trip.updated_at).strftime("%m/%d/%Y")
  trip_creater_id = Trip.objects.get(id=id).created_by


  context = {
    "this_user": User.objects.get(id=request.session["user_id"]),
    "this_trip": Trip.objects.get(id=id),

    "joined": this_trip.travelers.exclude(id=request.session["user_id"]),

    "start_date": start,
    "end_date": end,
    "created_at": created,
    "updated_at": updated,
    "trip_creator": User.objects.get(id=trip_creater_id)
  }
  return render(request, 'trip_info.html', context)
