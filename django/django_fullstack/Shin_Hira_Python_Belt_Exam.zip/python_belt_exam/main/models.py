from django.db import models

# Create your models here.
from django.db import models
from datetime import datetime, date
import re


class UserManager(models.Manager):
  def reg_validator(self, post_data):
    errors = {}
    if len(post_data["fname"]) < 2:
      errors['fname'] = "First Name must be at least 2 character!"

    if len(post_data['lname']) < 2:
      errors['lname'] = "Last Name must be at least 2 character!"

    email_regex = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
    if not email_regex.match(post_data['email']):
      errors['email'] = "Invalid email address!"

    if len(post_data['password']) < 8:
      errors['password'] = "Password must be at least 8 characters!"

    if post_data['password'] != post_data['confirm_password']:
      errors['confirm_password'] = "Passwords do not match!"
    return errors

  def login_validator(self, post_data):
    errors = {}
    email_regex = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
    if not email_regex.match(post_data['email']):
      errors['email'] = "Invalid email address!"

    if len(post_data['password']) < 8:
      errors['password'] = "Email or Password is incorrect please try again!"
    return errors


class User(models.Model):
  fname = models.CharField(max_length=23)
  lname = models.CharField(max_length=23)
  email = models.EmailField()
  password = models.CharField(max_length=255)
  created_at = models.DateTimeField(auto_now_add=True)
  updated_at = models.DateTimeField(auto_now=True)
  objects = UserManager()

class TripManager(models.Manager):
  def trip_validator(self, post_data):
    errors = {}
    if len(post_data["destination"]) < 3:
      errors['destination'] = "A trip destination must consist of at least 3 characters."

    if len(post_data['start_date']) == 0:
      errors['start_date'] = "A start date must be input."

    currentDate = str(datetime.now().date())
    print(currentDate)
    print("*"*100)
    print(post_data["start_date"])
    if currentDate >= post_data["start_date"]:
      errors["start_date"] = "No time traveling allowed"

    if len(post_data['end_date']) == 0:
      errors['end_date'] = "An end date must be input."
    elif post_data["end_date"] < post_data["start_date"]:
      errors["end_date"] = "End date must be dated after start date."



    if len(post_data["plan"]) == 0:
      errors["plan1"] = "A plan must be provided"
    elif len(post_data["plan"]) < 5:
      errors["plan1"] = "A plan must be more than 5 characters long."
    return errors


class Trip(models.Model):
  destination = models.CharField(max_length=50)
  start_date = models.DateField()
  end_date = models.DateField()
  plan = models.TextField()
  created_by = models.IntegerField()
  travelers = models.ManyToManyField(User, related_name="trips")
  created_at = models.DateTimeField(auto_now_add=True)
  updated_at = models.DateTimeField(auto_now=True)
  objects = TripManager()
