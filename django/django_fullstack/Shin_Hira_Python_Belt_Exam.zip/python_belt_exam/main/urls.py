from django.urls import path
from . import views

urlpatterns = [
    path('', views.root),
    path('reg_process', views.reg_process),
    path('login', views.login),
    path('logout', views.logout),
    path('delete/<id>', views.delete),
    # **************************************
    path('main', views.main),
    path('remove/<id>', views.remove),
    path('edit/<id>', views.edit_trip),
    path('join/<id>', views.join),
    path('cancel/<id>', views.cancel),
    # **************************************
    path('trips/new', views.create_trip),
    path('trips/new/form', views.create_trip_form),
    # **************************************
    path('edit/form/<id>', views.edit_trip_form),
    # **************************************
    path('trip_info/<id>', views.trip_info_page),
]