from django.shortcuts import render, redirect
from .models import Order, Product

def index(request):
    context = {
        "all_products": Product.objects.all()
    }
    return render(request, "store/index.html", context)

def checkout(request):
    quantity_from_form = int(request.POST["quantity"])
    productid = Product.objects.get(id=request.POST["id"])
    
    total_charge = quantity_from_form * productid.price
    print("Charging credit card...")
    neworder = Order.objects.create(quantity_ordered=quantity_from_form, total_price=total_charge)
    id = neworder.id

    return redirect(f"/refresh/{id}")



def refresh(request, id):
    totalsum = 0
    totalquantity = 0
    for i in Order.objects.all():
        totalsum += i.total_price
        totalquantity += i.quantity_ordered
    
    context = {
        "newOrder" : Order.objects.get(id=id),
        "totalsum" : totalsum,
        "totalquantity" : totalquantity
    }
    return render(request, "store/checkout.html", context)




def add(request):
    Product.objects.create(
        description = request.POST['item'],
        price = float(request.POST['price']),
        
    )
    print(Product.objects.all())
    return redirect("/")

def delete(request, id):
    d = Product.objects.get(id=id)
    d.delete()
    return redirect ("/")